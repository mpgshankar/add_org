# Exit on first error
set -e
export CONTAINERPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer
export CLIENTCLIID=$(docker ps --filter="name=cli" -aq | xargs)
echo $CLIENTCLIID
export LANGUAGE="golang"
export CLI_DELAY=3
export CLI_TIMEOUT=10
export CHANNEL_NAME="mychannel"

CLIENTUSER=$1
CLIENTIP=$2

docker cp client-script.sh $CLIENTCLIID:$CONTAINERPATH
# docker exec -it $CLIENTCLIID bash
docker exec $CLIENTCLIID ./client-script.sh $CHANNEL_NAME $CLI_DELAY $LANGUAGE $CLI_TIMEOUT
if [ $? -ne 0 ]; then
    echo "ERROR !!!! docker exec "$CLIENTCLIID failed
    exit 1
fi
